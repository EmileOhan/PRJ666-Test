### CoffeeScript

CoffeeScript is a programming language inspired by Ruby, Python and Haskell that transpiles to JavaScript.
