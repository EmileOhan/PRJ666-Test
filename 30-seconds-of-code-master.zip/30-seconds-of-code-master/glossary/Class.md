### Class

In object-oriented programming, a class is a template definition of an object's properties and methods.
