### WebGL

WebGL stands for Web Graphics Library and is a JavaScript API that can be used for drawing interactive 2D and 3D graphics.
WebGL is based on OpenGL and can be invoked within HTML `<canvas>` elements, which provide a rendering surface.
