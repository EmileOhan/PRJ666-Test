### UTF-8

UTF-8 stands for UCS Transformation Format 8 and is a commonly used character encoding.
UTF-8 is backwards compatible with ASCII and can represent any standard Unicode character.
