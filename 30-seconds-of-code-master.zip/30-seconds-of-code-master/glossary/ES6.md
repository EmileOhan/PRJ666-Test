### ES6

ES6 stands for ECMAScript 6 (also known as ECMAScript 2015), a version of the ECMAScript specification that standardizes JavaScript.
ES6 adds a wide variety of new features to the specification, such as classes, promises, generators and arrow functions.
