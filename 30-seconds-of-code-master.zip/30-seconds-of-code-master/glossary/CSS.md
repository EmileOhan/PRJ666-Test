### CSS

CSS stands for Cascading Style Sheets and is a language used to style web pages.
CSS documents are plaintext documents structured with rules, which consist of element selectors and property-value pairs that apply the styles to the specified selectors.
