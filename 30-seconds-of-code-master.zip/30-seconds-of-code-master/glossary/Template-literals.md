### Template literals

Template literals are strings that allow embedded expressions.
They support multi-line strings, expression interpolation and nesting.
