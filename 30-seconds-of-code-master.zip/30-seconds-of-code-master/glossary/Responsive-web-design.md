### Responsive web design

Responsive web design is a web development concept aiming to provide optimal behavior and performance of websites on all web-enabled devices.
Responsive web design is usually coupled with a mobile-first approach.
