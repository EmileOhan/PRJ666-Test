### Garbage collection

Garbage collection is a form of automatic memory management.
It attempts to reclaim memory occupied by objects that are no longer used by the program.
