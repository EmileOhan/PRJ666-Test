### URI

URI stands for Uniform Resource Identifier and is a text string referring to a resource.
A common type of URI is a URL, which is used for the identification of resources on the Web.
