### Stream

A stream is a sequence of data made available over time, often due to network transmission or storage access times.
