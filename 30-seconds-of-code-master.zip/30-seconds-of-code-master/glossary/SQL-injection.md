### SQL injection

SQL injection is a code injection technique, used to attack data-driven applications.
SQL injections get their name from the SQL language and mainly target data stored in relational databases.
