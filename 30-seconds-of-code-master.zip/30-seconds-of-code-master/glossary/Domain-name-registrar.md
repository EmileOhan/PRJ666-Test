### Domain name registrar

A domain name registrar is a company that manages the reservation of internet domain names.
A domain name registrar must be approved by a general top-level domain (gTLD) registry or a country code top-level domain (ccTLD) registry.
