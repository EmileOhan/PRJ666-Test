### XHTML

XHTML stands for EXtensible HyperText Markup Language and is a language used to structure web pages.
XHTML is a reformulation of the HTML document structure as an application of XML.
