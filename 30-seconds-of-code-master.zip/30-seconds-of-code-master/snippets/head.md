### head

Returns the head of a list.

Use `arr[0]` to return the first element of the passed array.

```js
const head = arr => arr[0];
```

```js
head([1, 2, 3]); // 1
```
